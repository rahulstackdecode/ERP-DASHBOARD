"use client";
import { useState, useEffect } from "react";
import { Clock, Plus, X } from "lucide-react";
import EmployeesStats from "../components/employees/EmployeesStats";
import TaskOverviewWrapper from "../components/employees/TaskOverview";
import Image from "next/image";

export default function Dashboard() {
    const [punchInTime, setPunchInTime] = useState<Date | null>(null);
    const [totalSeconds, setTotalSeconds] = useState<number>(0);
    const [accumulatedSeconds, setAccumulatedSeconds] = useState<number>(0);
    const [progress, setProgress] = useState<number>(0);
    const [buttonText, setButtonText] = useState<string>("Punch In");

    // Modal state
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Leave form states
    const [leaveType, setLeaveType] = useState("Medical Leave");
    const [fromDate, setFromDate] = useState("");
    const [toDate, setToDate] = useState("");
    const [reason, setReason] = useState("");

    /***date  */
    function formatDateTime(date: Date): string {
        const hours = date.getHours();
        const minutes = date.getMinutes();
        const ampm = hours >= 12 ? "PM" : "AM";
        const formattedHour = (hours % 12 || 12).toString().padStart(2, "0");
        const formattedMinutes = minutes.toString().padStart(2, "0");

        const time = `${formattedHour}:${formattedMinutes} ${ampm}`;

        const day = date.getDate().toString().padStart(2, "0");
        const month = date.toLocaleString("en-US", { month: "short" }); // e.g., Mar
        const year = date.getFullYear();

        return `${time}, ${day} ${month} ${year}`;
    }

    // Live timer
    useEffect(() => {
        let timer: number;
        if (punchInTime) {
            timer = window.setInterval(() => {
                const now = new Date();
                const diff = Math.floor((now.getTime() - punchInTime.getTime()) / 1000);
                setTotalSeconds(diff);
                setProgress(Math.min(((diff + accumulatedSeconds) / 28800) * 100, 100));
            }, 1000);
        }
        return () => clearInterval(timer);
    }, [punchInTime, accumulatedSeconds]);

    const handlePunchToggle = () => {
        if (!punchInTime) {
            // Punch In
            setPunchInTime(new Date());
            setButtonText("Punch Out");
        } else {
            // Punch Out
            const now = new Date();
            const diff = Math.floor((now.getTime() - punchInTime.getTime()) / 1000);
            setAccumulatedSeconds((prev) => prev + diff); // accumulate total worked seconds
            setPunchInTime(null);
            setTotalSeconds(0);
            setButtonText("Punch In");
        }
    };

    const formatTime = (seconds: number) => {
        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;
        return `${h.toString().padStart(2, "0")}:${m
            .toString()
            .padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
    };

    const getProductionTime = () => {
        const total = totalSeconds + accumulatedSeconds;
        const h = Math.floor(total / 3600);
        const m = Math.floor((total % 3600) / 60);
        return `${h}:${m < 10 ? "0" + m : m} hrs`;
    };

    // SVG circle configuration
    const svgSize = 150;
    const strokeWidth = 8;
    const radius = (svgSize - strokeWidth) / 2;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - (progress / 100) * circumference;

    // Handle leave form submit
    const handleApplyLeave = (e: React.FormEvent) => {
        e.preventDefault();

        // You can add form validation or API calls here
        alert(
            `Leave Applied!\nType: ${leaveType}\nFrom: ${fromDate}\nTo: ${toDate}\nReason: ${reason}`
        );

        // Reset and close modal
        setLeaveType("Medical Leave");
        setFromDate("");
        setToDate("");
        setReason("");
        setIsModalOpen(false);
    };

    return (
        <div>
            <h2 className="mb-6 font-medium text-[26px] sm:text-[32px] text-[color:var(--heading-color)] leading-snug">
                Employee Dashboard
            </h2>
            <div className="flex flex-col lg:flex-row gap-6">
                {/* Left Side */}
                <div className="flex-1 space-y-6">
                    {/* Welcome Card */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between w-full bg-white rounded-sm p-5 shadow-[0px_0px_1px_1px_rgba(198,198,198)]">
                        <div className="flex items-center gap-4">
                            <Image
                                src="/images/user-img.png"
                                alt="User Img"
                                width={56}
                                height={56}
                                className="rounded-full"
                            />
                            <div>
                                <h3 className="text-lg sm:text-xl font-semibold text-gray-900 leading-snug">
                                    Welcome Back, Admirra John
                                </h3>
                                <p className="text-sm sm:text-base font-light text-gray-600">
                                    Web Designer
                                </p>
                            </div>
                        </div>

                        <button
                            className="mt-4 sm:mt-0 flex items-center gap-2 px-4 py-2 text-[14px] sm:text-[15px] cursor-pointer font-medium text-white bg-[var(--primary-color)] rounded-sm transition hover:bg-[var(--btn-hover-bg)] w-full sm:w-auto justify-center"
                            onClick={() => setIsModalOpen(true)}
                        >
                            <Plus size={16} />
                            Apply Leave
                        </button>
                    </div>

                    {/* Stats Cards */}
                    <EmployeesStats />
                </div>

                {/* Right Side (Attendance) */}
                <div className="w-full lg:w-1/3 bg-[#FF6C0308] border border-[#FF6C03] rounded-md p-6">
                    <h4 className="text-center text-[16px] text-[#567D8E] mb-0">Attendance</h4>
                    <p className="text-center text-[22px] font-medium text-[#2C2C2C]">
                        {formatDateTime(new Date())}
                    </p>

                    {/* Circular Progress */}
                    <div className="flex justify-center my-6">
                        <div className="relative">
                            <svg className="w-[150px] h-[150px]">
                                <circle
                                    cx={svgSize / 2}
                                    cy={svgSize / 2}
                                    r={radius}
                                    stroke="#F7F7F7"
                                    strokeWidth={strokeWidth}
                                    fill="#ffffff"
                                />
                                <circle
                                    cx={svgSize / 2}
                                    cy={svgSize / 2}
                                    r={radius}
                                    stroke="#03C95A"
                                    strokeWidth={strokeWidth}
                                    fill="none"
                                    strokeDasharray={circumference}
                                    strokeDashoffset={strokeDashoffset}
                                    strokeLinecap="round"
                                    transform={`rotate(-90 ${svgSize / 2} ${svgSize / 2})`}
                                />
                            </svg>

                            <div className="absolute inset-0 flex flex-col items-center justify-center">
                                <p className="text-[14px] text-[#AAAAAA]">Total Hours</p>
                                <p className="text-[14px] font-medium text-[#2C2C2C]">
                                    {formatTime(totalSeconds + accumulatedSeconds)}
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Production Time */}
                    <button className="mx-auto flex px-4 py-2 rounded-sm bg-[#2C2C2C] text-white text-sm font-medium">
                        Production : {getProductionTime()}
                    </button>

                    {/* Punch Time Display */}
                    <p className="my-6 text-center text-[16px] text-black font-medium flex items-center justify-center gap-1">
                        <Clock className="w-4 h-4" />
                        {punchInTime &&
                            `Punch In at ${punchInTime.toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: true,
                            })}`}
                        {!punchInTime && accumulatedSeconds > 0 &&
                            `Punch Out at ${new Date().toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                                hour12: true,
                            })}`}
                        {!punchInTime && accumulatedSeconds === 0 && "Not Punched In"}
                    </p>

                    {/* Single Punch Button */}
                    <div className="flex justify-center">
                        <button
                            onClick={handlePunchToggle}
                            className={`px-6 py-3 cursor-pointer w-full rounded-sm font-medium text-white ${buttonText === "Punch In"
                                ? "bg-green-500 hover:bg-green-600"
                                : "bg-red-500 hover:bg-red-600"
                                }`}
                        >
                            {buttonText}
                        </button>
                    </div>
                </div>
            </div>

            {/* Today’s Task Overview Sec Table */}
            <TaskOverviewWrapper />

            {/* Leave Application Modal */}
            {isModalOpen && (
                <div
                    className="fixed inset-0 flex justify-center items-center z-50 px-4 sm:px-0"
                    style={{ backgroundColor: "#00000066" }}
                    onClick={() => setIsModalOpen(false)}
                >
                    <div
                        className="bg-white rounded-[5px] w-full max-w-[600px] relative sm:mx-auto"
                        onClick={(e) => e.stopPropagation()}
                    >

                        <div className="py-2 px-4 sm:px-8 sm:py-2  border border-[#0000001A]">
                            {/* Title */}
                            <h2 className="text-[#2C2C2C] font-medium text-[20px] sm:text-[28px]">
                                Apply For Leave
                            </h2>

                            {/* Close Icon */}
                            <button
                                className="cursor-pointer absolute top-2.5 sm:top-4 right-4 text-white bg-[#06A6F0] hover:bg-[#0784c6] rounded-full p-1 transition"
                                onClick={() => setIsModalOpen(false)}
                                aria-label="Close modal"
                            >
                                <X size={20} />
                            </button>
                        </div>

                        <form onSubmit={handleApplyLeave} className="space-y-4 py-4 px-4 sm:px-8 sm:py-8">
                            {/* Leave Type */}
                            <div>
                                <label
                                    htmlFor="leaveType"
                                    className="block mb-2 text-[#567D8E] text-[16px] font-normal"
                                >
                                    Leave Type
                                </label>
                                <div className="relative">
                                    <select
                                        id="leaveType"
                                        className="w-full border border-[#567D8E33] rounded-[4px] px-3 py-2 text-[15px] font-light text-[#2C2C2C] focus:outline-none"
                                        value={leaveType}
                                        onChange={(e) => setLeaveType(e.target.value)}
                                    >
                                        <option>Medical Leave</option>
                                        <option>Casual Leave</option>
                                        <option>Paid Leave</option>
                                        <option>Other</option>
                                    </select>
                                    {/* Custom arrow */}
                                    <svg
                                        className="pointer-events-none absolute right-3 top-3 w-4 h-4 text-gray-500"
                                        xmlns="http://www.w3.org/2000/svg"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor"
                                    >
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                                    </svg>
                                </div>
                            </div>

                            {/* From & To dates */}
                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label
                                        htmlFor="fromDate"
                                        className="block mb-2 text-[#567D8E] text-[16px] font-normal"
                                    >
                                        From
                                    </label>
                                    <input
                                        id="fromDate"
                                        type="date"
                                        className="w-full border border-[#567D8E33] rounded-[4px] px-3 py-2 text-[15px] font-light text-[#2C2C2C] focus:outline-none"
                                        value={fromDate}
                                        onChange={(e) => setFromDate(e.target.value)}
                                        required
                                    />
                                </div>
                                <div className="flex-1">
                                    <label
                                        htmlFor="toDate"
                                        className="block mb-2 text-[#567D8E] text-[16px] font-normal"
                                    >
                                        To
                                    </label>
                                    <input
                                        id="toDate"
                                        type="date"
                                        className="w-full border border-[#567D8E33] rounded-[4px] px-3 py-2 text-[15px] font-light text-[#2C2C2C] focus:outline-none"
                                        value={toDate}
                                        onChange={(e) => setToDate(e.target.value)}
                                        required
                                    />
                                </div>
                            </div>

                            {/* Reason */}
                            <div>
                                <label
                                    htmlFor="reason"
                                    className="block mb-2 text-[#567D8E] text-[16px] font-normal"
                                >
                                    Reason
                                </label>
                                <textarea
                                    id="reason"
                                    className="w-full border border-[#567D8E33] rounded-[4px] px-3 py-2 text-[15px] font-light text-[#2C2C2C] focus:outline-none"
                                    rows={4}
                                    value={reason}
                                    onChange={(e) => setReason(e.target.value)}
                                    required
                                />
                            </div>

                            {/* Apply Button */}
                            <div>
                                <button
                                    type="submit"
                                    className="cursor-pointer text-white bg-[#06A6F0] hover:bg-[#0784c6] rounded-[4px] px-8 py-2 font-medium "
                                >
                                    Apply
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}
