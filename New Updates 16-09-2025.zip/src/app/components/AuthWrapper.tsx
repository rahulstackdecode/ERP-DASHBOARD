"use client";

import { usePathname } from "next/navigation";
import ClientLayout from "./ClientLayout";

export default function AuthWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // exclude all auth routes by URL
  const authRoutes = ["/login", "/register", "/forgot-password", "/set-new-password"]; 

  if (authRoutes.includes(pathname)) {
    return <>{children}</>;
  }

  return <ClientLayout>{children}</ClientLayout>;
}
