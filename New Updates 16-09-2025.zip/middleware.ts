import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { createMiddlewareClient } from "@supabase/auth-helpers-nextjs";

export async function middleware(req: NextRequest) {
  const res = NextResponse.next();
  const supabase = createMiddlewareClient({ req, res });

  // Get current session
  const {
    data: { session },
  } = await supabase.auth.getSession();

  const pathname = req.nextUrl.pathname;

  // ✅ Public routes
  const publicPaths = [
    "/login",
    "/register",
    "/forgot-password",
    "/set-new-password",
  ];

  const isPublic = publicPaths.includes(pathname);
  const isStatic =
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.startsWith("/favicon.ico");

  // If user is NOT logged in → redirect to /login
  if (!session && !isPublic && !isStatic) {
    return NextResponse.redirect(new URL("/login", req.url));
  }

  // If user IS logged in and tries /login or /register → redirect to home
  if (session && (pathname === "/login" || pathname === "/register")) {
    return NextResponse.redirect(new URL("/", req.url));
  }

  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
